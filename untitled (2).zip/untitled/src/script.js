let currentImageIndex = 0;
let images = [
    {
        src: 'https://images.unsplash.com/photo-1517487881594-2787fef5ebf7?auto=format&fit=crop&w=600&q=80',
        caption: 'Aerial view of a dense forest with a misty atmosphere'
    },
    {
        src: 'https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?auto=format&fit=crop&w=600&q=80',
        caption: 'Mountain landscape with bright green meadows and rocky peaks'
    },
    {
        src: 'https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=600&q=80',
        caption: 'Night cityscape with illuminated skyscrapers and a river'
    },
    {
        src: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=600&q=80',
        caption: 'Sunlight filtering through a lush green forest'
    }
];

let favorites = [];
let slideshowInterval = null;

function showImage(index) {
    let galleryImage = document.getElementById('gallery-image');
    let caption = document.getElementById('caption');

    galleryImage.src = images[index].src;
    caption.innerText = images[index].caption;
}

function nextImage() {
    currentImageIndex = (currentImageIndex + 1) % images.length;
    showImage(currentImageIndex);
}

function startSlideshow() {
    if (slideshowInterval === null) {
        slideshowInterval = setInterval(nextImage, 2000);
    } else {
        clearInterval(slideshowInterval);
        slideshowInterval = null;
    }
}

function toggleCaptions() {
    let caption = document.getElementById('caption');
    caption.style.display = caption.style.display === 'none' ? 'block' : 'none';
}

function viewFavorites() {
    alert('Favorite images: ' + favorites.join(', '));
}

// Add images to favorites by clicking on the image
document.getElementById('gallery-image').addEventListener('click', () => {
    let currentImage = images[currentImageIndex].caption;
    if (!favorites.includes(currentImage)) {
        favorites.push(currentImage);
        alert(currentImage + ' added to favorites!');
    }
});

// Initially load the first image
showImage(currentImageIndex);
